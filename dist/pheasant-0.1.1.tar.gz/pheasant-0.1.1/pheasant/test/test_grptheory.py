#!/usr/bin/python3
# -*- coding: utf-8 -*-

import math
import unittest

import pheasant.grptheory as gp

class TestGroup(unittest.TestCase):
	'''
	Group function test class.
	'''
	
	def test_create(self):
		'''
		Create group test.
		'''
		pass

if __name__ == '__main__':
	print(__file__)
	unittest.main()

