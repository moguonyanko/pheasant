Python library for studying mathmatics.
