Python library for work mathmatics.
